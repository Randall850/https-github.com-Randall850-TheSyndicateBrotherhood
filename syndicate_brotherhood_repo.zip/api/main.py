import datetime
import uuid
import sys
import types
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

try:
    import ssl
except ModuleNotFoundError:
    ssl = types.SimpleNamespace()
    sys.modules['ssl'] = ssl

app = FastAPI()

bots_db = {}
users_db = {
    "Mrlist850": {
        "password": "the 13th key",
        "role": "boss",
        "access_level": "root"
    }
}
payouts_log = []

class CommandInput(BaseModel):
    command: str
    bot_id: Optional[str] = None
    family_id: Optional[str] = None
    count: Optional[int] = 1
    target: Optional[str] = None
    wallet_address: Optional[str] = None

class BotProfile(BaseModel):
    bot_id: str
    family_id: str
    status: str
    earning_rate_per_hour: float
    assigned_task: Optional[str] = None
    wallet: str
    created_at: datetime.datetime

class AuthRequest(BaseModel):
    username: str
    password: str

class WithdrawRequest(BaseModel):
    username: str
    password: str
    method: str
    destination: str
    amount: float
    notify_email: Optional[str] = None

@app.post("/auth")
def authenticate(auth: AuthRequest):
    user = users_db.get(auth.username)
    if not user or user['password'] != auth.password:
        raise HTTPException(status_code=401, detail="Access Denied")
    return {"message": "Access Granted", "role": user['role'], "access_level": user['access_level']}

@app.post("/deploy")
def deploy_bots(cmd: CommandInput):
    new_bots = []
    for _ in range(cmd.count):
        bot_id = str(uuid.uuid4())
        new_bot = BotProfile(
            bot_id=bot_id,
            family_id=cmd.family_id or "unassigned",
            status="earning",
            earning_rate_per_hour=generate_earning_rate(cmd.target),
            assigned_task=cmd.command,
            wallet=cmd.wallet_address or f"wallet_{bot_id[-6:]}",
            created_at=datetime.datetime.utcnow()
        )
        bots_db[bot_id] = new_bot.dict()
        new_bots.append(new_bot.dict())
    return {"deployed": new_bots}

def generate_earning_rate(target):
    rate_map = {
        "BugBounty": 320.0,
        "Crypto": 85.0,
        "Commerce": 120.0,
        "Freelance": 95.0,
        "Leads": 150.0,
        "Ads": 180.0,
        "Software": 210.0
    }
    return rate_map.get(target, 75.0)

@app.get("/bots")
def list_bots():
    return list(bots_db.values())

@app.get("/vault")
def nova_vault_balance():
    total = sum(bot['earning_rate_per_hour'] for bot in bots_db.values())
    return {
        "hourly_total": total,
        "daily_total": total * 24,
        "monthly_total": total * 24 * 30
    }

@app.get("/status")
def system_status():
    return {"status": "LIVE", "bot_count": len(bots_db), "timestamp": datetime.datetime.utcnow()}
