# SYNDICATE BROTHERHOOD – FULLSTACK DEPLOYMENT

**Live AI Ops Platform for monetizing bot crews in every digital vertical.**

## Backend (FastAPI)
- Start with `uvicorn main:app --reload`

## Frontend (React)
- Install dependencies: `npm install`
- Run dev server: `npm run dev`

## Environment
Fill in the `.env` with your credentials and server info

## Deployment
- Deploy backend to OpenChat Platform or custom VPS
- Deploy frontend to Vercel/Netlify
- Connect via `.env` to unify

## GitHub Package Includes:
- `/api` – FastAPI server
- `/dashboard` – React UI
- `.env` – Config
- `README.md` – Instructions
