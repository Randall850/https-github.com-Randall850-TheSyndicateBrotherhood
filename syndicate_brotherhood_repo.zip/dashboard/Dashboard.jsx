import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [vault, setVault] = useState({ hourly_total: 0, daily_total: 0, monthly_total: 0 });
  const [bots, setBots] = useState([]);
  const [status, setStatus] = useState("LIVE");

  useEffect(() => {
    fetchVault();
    fetchBots();
    fetchStatus();
  }, []);

  const fetchVault = async () => {
    const res = await axios.get("http://localhost:8000/vault");
    setVault(res.data);
  };

  const fetchBots = async () => {
    const res = await axios.get("http://localhost:8000/bots");
    setBots(res.data);
  };

  const fetchStatus = async () => {
    const res = await axios.get("http://localhost:8000/status");
    setStatus(res.data.status);
  };

  return (
    <div className="min-h-screen bg-black text-gold p-6">
      <h1 className="text-4xl font-bold mb-6">The Syndicate Brotherhood</h1>
      <div className="grid grid-cols-3 gap-6">
        <div className="bg-gray-900 p-4 rounded-2xl shadow-lg">
          <h2 className="text-xl font-bold mb-2">NovaVault</h2>
          <p>Hourly: ${vault.hourly_total.toFixed(2)}</p>
          <p>Daily: ${vault.daily_total.toFixed(2)}</p>
          <p>Monthly: ${vault.monthly_total.toFixed(2)}</p>
        </div>

        <div className="bg-gray-900 p-4 rounded-2xl shadow-lg col-span-2">
          <h2 className="text-xl font-bold mb-4">Bots Active</h2>
          <table className="w-full text-left">
            <thead>
              <tr>
                <th>ID</th>
                <th>Family</th>
                <th>Status</th>
                <th>Rate/hr</th>
                <th>Wallet</th>
              </tr>
            </thead>
            <tbody>
              {bots.map((bot) => (
                <tr key={bot.bot_id}>
                  <td>{bot.bot_id.slice(0, 6)}</td>
                  <td>{bot.family_id}</td>
                  <td>{bot.status}</td>
                  <td>${bot.earning_rate_per_hour}</td>
                  <td>{bot.wallet}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p className="mt-8 text-green-500">System Status: {status}</p>
    </div>
  );
};

export default Dashboard;
